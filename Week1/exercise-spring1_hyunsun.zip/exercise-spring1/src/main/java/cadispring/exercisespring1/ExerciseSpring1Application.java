package cadispring.exercisespring1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExerciseSpring1Application {

	public static void main(String[] args) {
		SpringApplication.run(ExerciseSpring1Application.class, args);
	}

}
